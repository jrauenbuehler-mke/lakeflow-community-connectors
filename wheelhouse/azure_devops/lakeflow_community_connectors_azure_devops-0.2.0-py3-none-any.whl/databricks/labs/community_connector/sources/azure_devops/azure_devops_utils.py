"""Utility functions for the Azure DevOps connector.

This module contains helper functions for API interaction, project/repo
resolution, and the PR auto-discovery pattern used across multiple tables.
"""

import re
import time
from datetime import datetime, timezone
from typing import Any, Callable

import requests

RETRIABLE_STATUS_CODES = {429, 500, 502, 503, 504}
MAX_RETRIES = 5
INITIAL_BACKOFF = 1.0  # seconds; doubled after each retry


def request_with_retry(
    session: requests.Session,
    url: str,
    params: dict[str, str],
) -> requests.Response:
    """Issue a GET with exponential backoff on retriable errors.

    Honors the ``Retry-After`` header when present, otherwise doubles
    the backoff (1, 2, 4, 8, 16 s).
    """
    backoff = INITIAL_BACKOFF
    resp = None
    for attempt in range(MAX_RETRIES):
        resp = session.get(url, params=params, timeout=30)
        if resp.status_code not in RETRIABLE_STATUS_CODES:
            return resp

        if attempt < MAX_RETRIES - 1:
            retry_after = resp.headers.get("Retry-After")
            try:
                wait = float(retry_after) if retry_after else backoff
            except (TypeError, ValueError):
                wait = backoff
            time.sleep(wait)
            backoff *= 2

    return resp


def api_get(
    session: requests.Session,
    url: str,
    params: dict[str, str],
    label: str,
) -> dict:
    """Make a GET request (with retry) and return the parsed JSON response.

    Raises RuntimeError on non-200 status codes with a descriptive
    message that includes *label* (e.g. ``"commits"``).
    """
    response = request_with_retry(session, url, params)
    if response.status_code != 200:
        raise RuntimeError(
            f"Azure DevOps API error for {label}: "
            f"{response.status_code} {response.text}"
        )
    return response.json()


def api_get_list(
    session: requests.Session,
    url: str,
    params: dict[str, str],
    label: str,
    key: str = "value",
) -> list[dict]:
    """GET a list endpoint and return the ``value`` array."""
    data = api_get(session, url, params, label)
    return data.get(key, [])


def resolve_projects(
    session: requests.Session,
    base_url: str,
    project: str | None,
) -> list[str]:
    """Return a list of project names to iterate over.

    If *project* is given, return it as a single-element list.
    Otherwise fetch all projects from the organization.
    """
    if project:
        return [project]
    items = api_get_list(
        session,
        f"{base_url}/_apis/projects",
        {"api-version": "7.1"},
        "projects",
    )
    return [p["name"] for p in items if p.get("name")]


def fetch_repos(
    session: requests.Session,
    base_url: str,
    project: str,
) -> list[dict]:
    """Fetch all repositories for a single project."""
    return api_get_list(
        session,
        f"{base_url}/{project}/_apis/git/repositories",
        {"api-version": "7.1"},
        "repositories",
    )


def fetch_prs(
    session: requests.Session,
    base_url: str,
    project: str,
    repo_id: str,
) -> list[dict]:
    """Fetch all pull requests (all statuses) for a repo."""
    url = (
        f"{base_url}/{project}/_apis/git/repositories"
        f"/{repo_id}/pullrequests"
    )
    return api_get_list(
        session,
        url,
        {"api-version": "7.1", "searchCriteria.status": "all"},
        "pullrequests",
    )


class ApiError(RuntimeError):
    """Non-200 API response, keeping the HTTP status for callers."""

    def __init__(self, message: str, status_code: int) -> None:
        super().__init__(message)
        self.status_code = status_code


def api_get_list_paged(
    session: requests.Session,
    url: str,
    params: dict[str, str],
    label: str,
) -> list[dict]:
    """GET a list endpoint that paginates via the continuation-token header.

    Build and pipeline endpoints return the next-page token in the
    ``x-ms-continuationtoken`` response header; it is passed back as the
    ``continuationToken`` query parameter until the header is absent.
    """
    items: list[dict] = []
    page_params = dict(params)
    while True:
        response = request_with_retry(session, url, page_params)
        if response.status_code != 200:
            raise ApiError(
                f"Azure DevOps API error for {label}: "
                f"{response.status_code} {response.text}",
                response.status_code,
            )
        items.extend(response.json().get("value", []))
        token = response.headers.get("x-ms-continuationtoken")
        if not token:
            return items
        page_params["continuationToken"] = token


def parse_ts(value: str) -> datetime:
    """Parse an Azure DevOps ISO 8601 timestamp into an aware datetime.

    ADO emits up to 7 fractional digits and a trailing ``Z``, neither of
    which ``datetime.fromisoformat`` accepts on Python < 3.11. Comparing
    parsed values avoids lexicographic errors between e.g. ``...00Z`` and
    ``...00.5Z``.
    """
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    match = re.match(r"^(.*?)\.(\d+)(.*)$", text)
    if match:
        text = f"{match.group(1)}.{(match.group(2) + '000000')[:6]}{match.group(3)}"
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def nullify_empty(record: dict, *keys: str) -> None:
    """Replace missing or empty-dict nested structs with ``None``."""
    for key in keys:
        if key not in record or record[key] == {}:
            record[key] = None


# --------------------------------------------------------------------------- #
# PR sub-resource auto-discovery helper
# --------------------------------------------------------------------------- #

def for_each_pr(
    session: requests.Session,
    base_url: str,
    projects: list[str],
    table_options: dict[str, str],
    callback: Callable[
        [str, str, int], list[dict[str, Any]]
    ],
) -> list[dict[str, Any]]:
    """Iterate over pull requests and collect records via *callback*.

    The three-tier auto-discovery pattern used by threads, work-items,
    commits, and reviewers tables:

    1. If ``repository_id`` **and** ``pullrequest_id`` are in
       *table_options* → call *callback* once.
    2. If only ``repository_id`` → iterate all PRs in that repo.
    3. If neither → iterate all repos in each project, then all PRs.

    *callback(project, repo_id, pr_id)* must return a list of enriched
    record dicts for that single PR.
    """
    repo_id = table_options.get("repository_id")
    pr_id = table_options.get("pullrequest_id")

    all_records: list[dict[str, Any]] = []

    for project in projects:
        if repo_id and pr_id:
            all_records.extend(
                callback(project, repo_id, int(pr_id))
            )
        else:
            target_ids = (
                [repo_id] if repo_id
                else [r["id"] for r in
                      fetch_repos(session, base_url, project)
                      if r.get("id")]
            )
            for rid in target_ids:
                try:
                    prs = fetch_prs(
                        session, base_url, project, rid
                    )
                except RuntimeError:
                    continue
                for pr in prs:
                    pid = pr.get("pullRequestId")
                    if pid is None:
                        continue
                    try:
                        all_records.extend(
                            callback(project, rid, pid)
                        )
                    except RuntimeError:
                        continue

    return all_records
